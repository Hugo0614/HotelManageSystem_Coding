package project;

public class ExUnknownRoomType extends Exception{
	public ExUnknownRoomType() { super("Unknown Room Type"); }
//    public ExUnknownRoomType(String message) { super(message); }
}
