package project;

public interface HygieneStatus {
	String getStatus();
//	void changeStatus();
}
