package project;

public class ExNoGuestsRecord extends Exception{
	public ExNoGuestsRecord() { super("No guests checkIn record"); }
//    public ExNoGuestsRecord(String message) { super(message); }
}
