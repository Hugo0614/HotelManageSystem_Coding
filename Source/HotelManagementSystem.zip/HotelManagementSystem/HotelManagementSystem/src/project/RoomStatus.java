package project;

public interface RoomStatus {
	String getStatus();
}
