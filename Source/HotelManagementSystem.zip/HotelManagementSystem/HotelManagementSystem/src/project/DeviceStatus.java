package project;

public interface DeviceStatus {
	String getStatus();
}
