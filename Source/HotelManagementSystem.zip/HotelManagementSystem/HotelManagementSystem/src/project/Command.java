package project;

interface Command
{
    void execute(String[] cmdParts);
}