package project;

public class ExUnknownArguments extends Exception{
	public ExUnknownArguments() { super("Unknown Commands"); }
//    public ExUnknownArguments(String message) { super(message); }
}
