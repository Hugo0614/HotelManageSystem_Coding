package project;

public class ExMultiRegistered extends Exception{
	public ExMultiRegistered() { super("Sorry, every guest can only register once"); }
//    public ExMultiRegistered(String message) { super(message); }
}
